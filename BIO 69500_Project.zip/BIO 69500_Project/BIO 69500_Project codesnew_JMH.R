# BIO 69500 (DATA SCIENCE FOR BIOLOGISTS)
# Term Project Codes
# NAME: JAMES MYERS-HANSEN (GRAD STUDENT)
# DATE: 12/16/2022

library(tidyverse)
library(dplyr)
library (lme4)

setwd("D:/DATA/Purdue University/Purdue_Fall 2022/BIO 69500 (Data Science for Biologists)/Project")


#1 Plots for pfcrt_pm

pfcrt_pm_region <- read_csv("pfcrt_pm_region.csv")

### Pfcrt76T Prevalence vs Year_All regions, between 1995 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = Year, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Year") + ylab("Pfcrt 76T Prevalence") 
ggsave("pfcrt_pm_region_p1.png")

### Pfcrt76T Prevalence vs Year_All regions, but between 1995 and 2005
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = Year, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Year") + ylab("Pfcrt 76T Prevalence") 
ggsave("pfcrt_pm_region_p1a.png")

### Pfcrt76T Prevalence vs Year_All regions, but between 2005 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = Year, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Year") + ylab("Pfcrt 76T Prevalence") 
ggsave("pfcrt_pm_region_p1b.png")

# Pfcrt76T Prevalence vs Year_Facetted for Africa, between 1995 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = Year, y = present/tested) + geom_point() + facet_wrap(~Region) + geom_smooth(method = "lm")+ xlab("Year") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p2.png")

# Pfcrt76T Prevalence vs Year_Facetted for Africa, but between 1995 and 2005
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = Year, y = present/tested) + geom_point() + facet_wrap(~Region) + geom_smooth(method = "lm")+ xlab("Year") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p2a.png")

# Pfcrt76T Prevalence vs Year_Facetted for Africa, but between 2005 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = Year, y = present/tested) + geom_point() + facet_wrap(~Region) + geom_smooth(method = "lm")+ xlab("Year") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p2b.png")



###Pfcrt76T Prevalence vs PR_All regions, between 1995 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = PR, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Parasite Rate") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p3.png")

###Pfcrt76T Prevalence vs PR_All regions, but between 1995 and 2005
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = PR, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Parasite Rate") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p3a.png")

###Pfcrt76T Prevalence vs PR_All regions, but between 2005 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = PR, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Parasite Rate") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p3b.png")


# Pfcrt76T Prevalence vs PR_Facetted for Africa,  between 1995 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = PR, y = present/tested) + geom_point() + facet_wrap(~Region) +  geom_smooth(method = "lm")+ xlab("Parasite Rate") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p4.png")

# Pfcrt76T Prevalence vs PR_Facetted for Africa,  but between 1995 and 2005
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = PR, y = present/tested) + geom_point() + facet_wrap(~Region) +  geom_smooth(method = "lm")+ xlab("Parasite Rate") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p4a.png")

# Pfcrt76T Prevalence vs PR_Facetted for Africa, but between 2005 and 2020
ggplot(data=pfcrt_pm_region %>% filter(`marker type` == "pfcrt 76T", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = PR, y = present/tested) + geom_point() + facet_wrap(~Region) +  geom_smooth(method = "lm")+ xlab("Parasite Rate") + ylab("Pfcrt 76T Prevalence")
ggsave("pfcrt_pm_region_p4b.png")


# Plot of the relationship between Region and Year varied between pfcrt76T Prevalence.
pfcrt_pm1_region<- pfcrt_pm_region %>%mutate(Prev76T = (present/(tested))*100)
pfcrt_pm2_region<-pfcrt_pm1_region%>%mutate(Prev76TCat = cut(Prev76T,breaks=10*(0:10),include.lowest=T))
ggplot(data = pfcrt_pm2_region, aes (y = Region, x = Year,colour = Prev76TCat)) + geom_point(size = 3) + scale_color_viridis_d(name="Pfcrt 76T Prevalence") + theme_classic() + xlab ("Year") + ylab ("Region")
ggsave("pfcrt 76T_Timep1.png")

# Plot of the relationship between Region and Year varied between Parasite rate.
pfcrt_pm3_region<-pfcrt_pm_region%>%mutate(PRCat = cut(PR,breaks=10*(0:10),include.lowest=T))
ggplot(data = pfcrt_pm3_region, aes (y = Region, x = Year,colour = PRCat)) + geom_point(size = 3) + scale_color_viridis_d(name="PR") + theme_classic() + xlab ("Year") + ylab ("Region")
ggplot(data = pfcrt_pm3_region, aes (y = Region, x = Year,colour = PRCat)) + geom_point(size = 3) + scale_color_viridis_d(name="PR") + theme_classic() + xlim(2010,2020) + xlab ("Year") + ylab ("Region")
ggsave("pfcrt 76T_Timep2.png")



#2 Plots for pfmdr1_pm

pfmdr1_pm_region <- read_csv("pfmdr1_pm_region.csv")

### Pfmdr1 86Y Prevalence vs Year_All regions, between 1995 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = Year, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Year") + ylab("Pfmdr1 86Y Prevalence") 
ggsave("pfmdr1_pm_region_p1.png")

### Pfmdr1 86Y Prevalence vs Year_All regions, but between 1995 and 2005
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = Year, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Year") + ylab("Pfmdr1 86Y Prevalence") 
ggsave("pfmdr1_pm_region_p1a.png")

### Pfmdr1 86Y Prevalence vs Year_All regions, but between 2005 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = Year, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Year") + ylab("Pfmdr1 86Y Prevalence") 
ggsave("pfmdr1_pm_region_p1b.png")

# Pfmdr1 86Y Prevalence vs Year_Facetted for Africa, between 1995 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = Year, y = present/tested) + geom_point() + facet_wrap(~Region) + geom_smooth(method = "lm")+ xlab("Year") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p2.png")

# Pfmdr1 86Y Prevalence vs Year_Facetted for Africa, but between 1995 and 2005
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = Year, y = present/tested) + geom_point() + facet_wrap(~Region) + geom_smooth(method = "lm")+ xlab("Year") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p2a.png")

# Pfmdr1 86Y Prevalence vs Year_Facetted for Africa, but between 2005 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = Year, y = present/tested) + geom_point() + facet_wrap(~Region) + geom_smooth(method = "lm")+ xlab("Year") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p2b.png")



###Pfmdr1 86Y Prevalence vs PR_All regions, between 1995 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = PR, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Parasite Rate") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p3.png")

###Pfmdr1 86Y Prevalence vs PR_All regions, but between 1995 and 2005
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = PR, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Parasite Rate") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p3a.png")

###Pfmdr1 86Y Prevalence vs PR_All regions, but between 2005 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa", "SEA", "South America")))+ aes(x = PR, y = present/tested) + geom_point(aes(color=as.factor(Region)))+ geom_smooth(method = "lm") + xlab("Parasite Rate") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p3b.png")


# Pfmdr1 86Y Prevalence vs PR_Facetted for Africa, between 1995 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = PR, y = present/tested) + geom_point() + facet_wrap(~Region) +  geom_smooth(method = "lm")+ xlab("Parasite Rate") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p4.png")

# Pfmdr1 86Y Prevalence vs PR_Facetted for Africa, but between 1995 and 2005
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (1995:2005), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = PR, y = present/tested) + geom_point() + facet_wrap(~Region) +  geom_smooth(method = "lm")+ xlab("Parasite Rate") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p4a.png")

# Pfmdr1 86Y Prevalence vs PR_Facetted for Africa, but between 2005 and 2020
ggplot(data=pfmdr1_pm_region %>% filter(`marker type` == "pfmdr1 86Y", Year %in% (2005:2020), Region %in% c("West Africa","Central Africa", "East Africa", "Southern Africa"))) + aes(x = PR, y = present/tested) + geom_point() + facet_wrap(~Region) +  geom_smooth(method = "lm")+ xlab("Parasite Rate") + ylab("Pfmdr1 86Y Prevalence")
ggsave("pfmdr1_pm_region_p4b.png")


# Plot of the relationship between Region and Year varied between pfmdr1 86Y Prevalence.
pfmdr1_pm1_region<- pfmdr1_pm_region %>%mutate(Prev86Y = (present/(tested))*100)
pfmdr1_pm2_region<-pfmdr1_pm1_region%>%mutate(Prev86YCat = cut(Prev86Y,breaks=10*(0:10),include.lowest=T))
ggplot(data = pfmdr1_pm2_region, aes (y = Region, x = Year,colour = Prev86YCat)) + geom_point(size = 3) + scale_color_viridis_d(name="Pfmdr1 86Y Prevalence") + theme_classic() + xlab ("Year") + ylab ("Region")
ggsave("pfmdr1 86Y_Timep1.png")

# Plot of the relationship between Region and Year varied between Parasite rate.
pfmdr1_pm3_region<-pfmdr1_pm_region%>%mutate(PRCat = cut(PR,breaks=10*(0:10),include.lowest=T))
ggplot(data = pfmdr1_pm3_region, aes (y = Region, x = Year,colour = PRCat)) + geom_point(size = 3) + scale_color_viridis_d(name="PR") + theme_classic() + xlab ("Year") + ylab ("Region")
ggplot(data = pfmdr1_pm3_region, aes (y = Region, x = Year,colour = PRCat)) + geom_point(size = 3) + scale_color_viridis_d(name="PR") + theme_classic() + xlim(2010,2020) + xlab ("Year") + ylab ("Region")
ggsave("pfmdr1 86Y_Timep2.png")


######

#Models

#pfcrt

pfcrt_pm_m <- pfcrt_pm1_region

# criterion for running the contrasts in afex
set_sum_contrasts()

# views dataset
View(pfcrt_pm_m)

# summary of the types of variables and their values
str(pfcrt_pm_m)

# assign factors
pfcrt_pm_m$study_Id <- as.factor(pfcrt_pm_m$study_Id)

# model 1 set up with the most complex random structure
M1 <- mixed(Prev76T ~ PR + Year + (1|study_Id), data = pfcrt_pm_m, method = "KR",
            control = lmerControl(optCtrl = list(maxfun = 1e6)), expand_re = TRUE)
anova(M1)
summary(M1)



#pfmdr1

pfmdr1_pm_m <- pfmdr1_pm1_region

# criterion for running the contrasts in afex
set_sum_contrasts()

# views dataset
View(pfmdr1_pm_m)

# summary of the types of variables and their values
str(pfmdr1_pm_m)

# assign factors
pfmdr1_pm_m$study_Id <- as.factor(pfmdr1_pm_m$study_Id)

# model 2 set up with the most complex random structure
M2 <- mixed(Prev86Y ~ PR + Year + (1|study_Id), data = pfmdr1_pm_m, method = "KR",
            control = lmerControl(optCtrl = list(maxfun = 1e6)), expand_re = TRUE)
anova(M2)
summary(M2)









